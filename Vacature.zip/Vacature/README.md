# ZZEP_online

### Getting started

Check how to get up and running with PyCharm [here](https://omniscalenl.bitbucket.io/getting-started/).

### Installation notes for local development

 * Create a virtual env using python 3.6.5
 * Run `pip install Django==1.11` before running the `pip install -r requirements.txt`
 * Make sure that the Wagtail version in `src/backend/web/requirements/production.txt` is enabled
 * Check if in the `src/backend/web/nieuwsoverkindervoeding/settings/base.py` all Wagtail implementation's are enabled and that default language is set to your preferred language.
 * In the same folder, open copy `local-dist.py`, paste it in the same folder and rename the file to `local.py` and change the database fields to your desired database. Note that we are using mysql.
 * In the same file `local.py` change Debug to Debug = False
 * `**still applicable**`If you have an existing database, migrate it in through `**still apllicable**`   
 
### CMS
 * log into the cms and on the left sidebar click on 'Page's'. After that click on `Welcome to your first Wagtail site!' and click on the button 'add child'.
 * Add a Homepage page and name it 'Homepage'. 
 * After the Homepage page has been added go to settings and click on Sites. Then click on localhost and at the field 'start page' click on the 'chose another start page' and chose the recently created Homepage.
 * To add any other custom page go back to Homepage (Page's -> Your first Wagtail site -> Homepage) and add a child to it. 
 * Note that some pages can only be created as children under a specific page.
 
##### Important:

 * When adding children to Homepage the following pages MUST have these names as slugs:
 * Vacancy's: 'vacatures'
 * Job Offer: 'opdrachtgever'
 * Open Application: 'open-sollicitatie'
 * Contact: 'contact'
 * Confirm page: 'bedankt'
 
### Email
 * We will be using Mandrill / Mailchimp through [django-anymail](https://anymail.readthedocs.io/en/stable/)
 * To enable sending emails through their API, enable the following in your `local.py`:
```python
# Enable the line below for Mandrill
EMAIL_BACKEND = "anymail.backends.mandrill.EmailBackend"
``` 

### MySQL
 * We are using mysql (version 1.3.10) for this project.
 
### Relevant
 * For error tracking this project is using Sentry
 * For sending emails we are using Mandrill 
 
 
