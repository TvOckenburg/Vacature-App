import $ from 'jquery';

import {
    removeNoJS,
    enableHamburgerMenu
} from "./components/JqueryComponents";
import sharer from 'sharer.js';


import {
    initCustomUpload
} from "./components/customfileinput";



$(document).ready(function() {
    removeNoJS();
    initCustomUpload(document);
    enableHamburgerMenu();
});
