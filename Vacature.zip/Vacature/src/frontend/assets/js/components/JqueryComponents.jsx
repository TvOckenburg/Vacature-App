import $ from 'jquery';

export const removeNoJS = () => {
    $('html').removeClass('no-js');
    $('html').addClass('js-enabled');
};

export const enableHamburgerMenu = () => {
    let $hamburger = $('.hamburger');

    function toggleMenu() {
        $hamburger.toggleClass('is-active');
        $('.page-header').toggleClass('navigation-visible');
    }

    $hamburger.on('click', function(e) {
        toggleMenu();
    });
};
