const path = require('path');
const glob = require('glob');

// Import all required plugins for Webpack
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const BundleTrackerPlugin = require('webpack-bundle-tracker');
const StyleLintPlugin = require('stylelint-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const WepackAssetsManifestPlugin = require('webpack-assets-manifest');
const SuppressEntryChunksPlugin = require("./suppress-entry-chunks-plugin"); // Note: this is locally(!)
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');

const sourcePath = path.resolve(__dirname);
const bundlesPath = path.resolve(__dirname, '../backend/web/base/static/bundles');
const globOptions = {
    cwd: sourcePath
};


module.exports = (env, argv) => {

    // argv.mode now contains the value for --mode= (for the commands in package.json)
    // test: console.log(argv.mode);

    const isProd = argv.mode == 'production' ? true : false;

    // If we are running in production-mode, append hashes based on the filesize/content
    const baseName = isProd ? '[name]-[hash].[ext]' : '[name].[ext]';
    const chunkBaseName = isProd ? '[name]-[contenthash].[ext]' : '[name].[ext]';

    const postcssPluginsDev = [
        require('autoprefixer'),
    ];

    const postcssPluginsProd = [
        require('autoprefixer'),
        require('cssnano')({
            preset: [
                'default',
                {
                    discardComments: {
                        removeAll: true,
                    },
                    svgo: false
                }
            ]
        })

    ];

    return {

        optimization: {
            minimizer: [new UglifyJsPlugin({
                test: /\.js(\?.*)?$/i,
                uglifyOptions: {
                    warnings: false,
                    parse: {},
                    compress: {},
                    mangle: {
                        toplevel: true,
                        properties: false // Setting this to true could cause errors
                    },
                    output: {
                        comments: false
                    },
                    toplevel: true,
                    nameCache: null,
                    ie8: false,
                    keep_fnames: false,
                }
            })]
        },

        // Control the information that it output in the build-info (https://webpack.js.org/configuration/stats/).
        // We basically only want to know the build-status and linter-warnings.
        stats: {
            modules: false,
            children: false
        },

        // The context from with entry points/plugins/etc must start to resolve paths
        context: sourcePath,

        // The entrypoints that webpack will process; each index index in this object will result in a corresponding
        // <index.js> and/or <index>.css in the bundles directory. Since Webpack started as a JS-bundling application,
        // <index>.js bundles are created by default - even if they are (mostly) empty. Using the SuppressEntryChunksPlugin
        // we can control which files should not be emitted when building.
        entry: {

            // The main js(x) for the entire application, since we are not using code-splitting (as in, .js per page)
            main: './assets/js/main.jsx',

            // The default and print (s)css for the application
            screen: './assets/scss/screen.scss',
            // print: './assets/scss/print.scss',

            // gather all files in the images directory (which are copied to the bundles/assets/images directory
            images: glob.sync("./assets/images/*.*", globOptions)
        },

        // Output file & location for the generated bundles
        output: {
            path: bundlesPath,
            filename: chunkBaseName.replace(/\[ext]/i, 'js')
        },

        // Debugging aid (see https://webpack.js.org/configuration/devtool/ for more options)
        devtool: isProd ? '(none)' : 'source-map',

        module: {

            // Add the files matching the regex to the bundle as they are, and do not resolve import/require statements
            noParse: /jquery/,

            // Webpack 1 & 2 used module.loaders (for which support will be removed at some point), Webpack 3 has switched
            // to module.rules which allow for more control (https://webpack.js.org/configuration/module/#module-rules)
            rules: [

                // 1. js(x)
                {
                    test: /\.jsx?$/,
                    exclude: /node_modules/,
                    use: {
                        loader: 'babel-loader',
                        options: {
                            // Adding the presets for Babel here, so we don't need an additional .babelrc
                            presets: [
                                'babel-preset-env',
                                'babel-preset-react'
                            ],
                            plugins: [
                                require('babel-plugin-transform-object-rest-spread'),
                                require('babel-plugin-transform-react-jsx')
                            ]
                        }
                    }
                },

                // 2. (s)css
                // The loaders are processed from bottom-to-top: css-loader(postcss-loader(sass-loader(resource))))
                {
                    test: /\.(css|scss)$/,
                    use: [
                        MiniCssExtractPlugin.loader,
                        'css-loader',
                        {
                            loader: "postcss-loader",
                            options: {
                                plugins: isProd ? postcssPluginsProd : postcssPluginsDev
                            }
                        },
                        'sass-loader',
                    ]
                },

                // 3. images
                {
                    test: /\.(png|svg|jpe?g|gif)$/,
                    use: [{
                        loader: "file-loader",
                        options: {
                            name: "[path]" + baseName
                        }
                    }]
                },

                // 4. fonts
                {
                    test: /\.(woff|woff2|eot|ttf|otf)$/,
                    use: [{
                        loader: "file-loader",
                        options: {
                            name: "[path][name].[hash].[ext]"
                        }
                    }]
                }
            ]
        },

        // Plugins that are used by Webpack are instantiated here, with their desired configuration and options
        plugins: [

            // Extract all (s)css that has been found throughout the entry point to a separate .css bundle
             new MiniCssExtractPlugin({
                filename: chunkBaseName.replace(/\[ext]/i, 'css'),
            }),

            // Save information on the created bundles to a file for later use (django-webpack-loader)
            new BundleTrackerPlugin({
                filename: 'webpack-stats.json',
                publicPath: '/static/bundles/',
                indent: 4
            }),

            // When processing scss, pass it through stylelint according to the rules in .stylelintrc
            new StyleLintPlugin({
                configFile: '.stylelintrc',
                context: sourcePath,
                files: '/**/*.scss',
                failOnError: false,
                quiet: false
            }),

            // When building the bundles, remove the old assets and bundles
            new CleanWebpackPlugin([
                bundlesPath + '/assets',
                bundlesPath + '/**/*.*'
            ], {
                root: path.resolve(__dirname),
                watch: true,
                allowExternal: false,
                verbose: false
            }),

            // Some entrypoints do not require a .js bundles, we can provide the names of those entry points here
            new SuppressEntryChunksPlugin([
                'screen',
                'print',
                'images'
            ]),

            // Build a manifest
            new WepackAssetsManifestPlugin({
                output: bundlesPath + '/manifest.json',
                merge: true
            }),
        ],
        resolve: {
            extensions: [
                '.js',
                '.jsx',
                '.json'
            ]
        }
    };
};
