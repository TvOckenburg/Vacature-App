"""Default config"""
from django.conf import settings
from django.conf.urls import include, url
from django.contrib import admin
from django.http import HttpResponse


def bad(request):
    """Simulates a server error"""
    1 / 0


urlpatterns = [
    url(r'', include('base.urls')),

    # if no robots.txt configed in nginx, we trigger a disallow all
    url(r'^robots.txt$', lambda request: HttpResponse("User-agent: *\nDisallow: /", content_type="text/plain")),
    url(r'^bad/?', bad),
    url(r'^admin/', include(admin.site.urls)),
]

# if rosetta (string translation app) is enabled
if 'rosetta' in settings.INSTALLED_APPS:
    urlpatterns += [
        url(r'^rosetta/', include('rosetta.urls')),
    ]

# if wagtail is enabled
if 'wagtail.core' in settings.INSTALLED_APPS:

    from wagtail.admin import urls as wagtailadmin_urls
    from wagtail.documents import urls as wagtaildocs_urls
    from wagtail.core import urls as wagtail_urls

    urlpatterns += [
        url(r'^cms/', include(wagtailadmin_urls)),
        url(r'^documents/', include(wagtaildocs_urls)),
        url(r'', include(wagtail_urls)),
    ]




# only enable if in debug mode
if settings.DEBUG:

    # enable dynamic serving for static and media files during development
    from django.conf.urls.static import static

    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

    # enable the debug toolbar
    if 'debug_toolbar' in settings.INSTALLED_APPS:

        import debug_toolbar

        urlpatterns += [
            url(r'^__debug__/', include(debug_toolbar.urls)),
        ]
