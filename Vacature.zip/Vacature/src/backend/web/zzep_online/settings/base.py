"""
Django settings for zzep_online project.

For more information on this file, see
https://docs.djangoproject.com/en/1.11/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/1.11/ref/settings/
"""
from pathlib import Path

BASE_DIR = Path('.').resolve().parent.parent.parent

DEBUG = False

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.11/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = r""

# A list of strings representing the host/domain names that this
# Django site can serve.
ALLOWED_HOSTS = []

# A tuple that lists people who get code error notifications.
ADMINS = (
)

# A tuple in the same format as ADMINS that specifies who should get broken
# link notifications when BrokenLinkEmailsMiddleware is enabled.
MANAGERS = ADMINS

# Your project root
PROJECT_ROOT = BASE_DIR / 'src' / 'backend' / 'web'

# A tuple of strings designating all applications that are enabled in
# this Django installation.
BASE_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rosetta',
]

THIRD_PARTY_APPS = [
    'dbbackup',

    # Enable the lines below to enable the Wagtail CMS

    'wagtail.contrib.forms',
    'wagtail.contrib.redirects',
    'wagtail.contrib.settings',
    # 'wagtail.contrib.styleguide',
    'wagtail.embeds',
    'wagtail.sites',
    'wagtail.users',
    'wagtail.snippets',
    'wagtail.documents',
    'wagtail.images',
    'wagtail.search',
    'wagtail.admin',
    'wagtail.core',
    'modelcluster',
    'taggit',
    'widget_tweaks',
]

CUSTOM_APPS = [
    'base',
]

INSTALLED_APPS = CUSTOM_APPS + THIRD_PARTY_APPS + BASE_APPS

EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

if 'wagtail.core' in INSTALLED_APPS:
    MIDDLEWARE += [
        'wagtail.core.middleware.SiteMiddleware',
        'wagtail.contrib.redirects.middleware.RedirectMiddleware',
    ]

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'APP_DIRS': True,
        'OPTIONS': {
            'debug': False,
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.media',
                'django.template.context_processors.request',
                'django.template.context_processors.i18n',
                'django.template.context_processors.static',
                'django.template.context_processors.csrf',
                'django.template.context_processors.tz',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'wagtail.contrib.settings.context_processors.settings',
                'base.context_processors.zzep_settings',
            ],
        },
    },
]

ROOT_URLCONF = 'zzep_online.urls'

WSGI_APPLICATION = 'zzep_online.wsgi.application'

# A dictionary specifying the package where migration modules can be
# found on a per-app basis.
MIGRATION_MODULES = {
}

# Database
# https://docs.djangoproject.com/en/1.11/ref/settings/#databases
DATABASES = {
}

# Password validation
# https://docs.djangoproject.com/en/1.11/ref/settings/#auth-password-validators
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
# https://docs.djangoproject.com/en/1.11/topics/i18n/
TIME_ZONE = 'Europe/Amsterdam'

USE_I18N = True

USE_L10N = True

USE_TZ = True

# Language code for this installation. All choices can be found here:
# http://www.i18nguy.com/unicode/language-identifiers.html
LANGUAGE_CODE = 'nl'

# A tuple of all available languages
LANGUAGES = (
    ('nl', 'Nederlands'),
    ('en', 'English')
)
DEFAULT_INDEX_TABLESPACE = 15
DJANGO_SETTINGS_MODULE = 'zzep_online.settings'

# A tuple of directories where Django looks for translation files.
LOCALE_PATHS = (
    str(PROJECT_ROOT / 'locale'),
)

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.11/howto/static-files/
STATIC_URL = '/static/'
STATIC_ROOT = str(BASE_DIR / 'static')

# User-uploaded files
# https://docs.djangoproject.com/en/1.11/topics/files/
MEDIA_URL = '/media/'
MEDIA_ROOT = str(BASE_DIR / 'media')

# Settings for django-dbbackup
DBBACKUP_STORAGE = 'django.core.files.storage.FileSystemStorage'
DBBACKUP_STORAGE_OPTIONS = {
    'location': str(BASE_DIR / 'backups')
}


def backup_filename(databasename, servername, datetime, extension, content_type):
    return '%s_%s.%s' % (databasename, datetime, extension)


DBBACKUP_FILENAME_TEMPLATE = backup_filename

AUTH_USER_MODEL = 'base.AuthUser'

# Settings for Wagtail
WAGTAIL_SITE_NAME = 'ZZEP.online'
WAGTAILIMAGES_JPEG_QUALITY = 40

GA_TRACKING_ID = 'UA-122472088-1'

ENVIRONMENTS = {

    'global': {
        'code_repo': 'git@bitbucket.org:omniscale_nl/zzep_online.git',
    },

    'production': {
        'hosts': ['zzep@vps3.omniscale.nl'],
        'virtualenv': '/home/zzep/www/zzep.online/production-env',
        'project_root': '/home/zzep/www/zzep.online/production',
        'static_dir': 'static',
        'code_dir': 'src/backend/web',
        'branch': 'master',
        'origin': 'origin',
        'compress': False,
        'uwsgi': True,
        'uwsgi_ini': 'production',
        'environment': 'production',
    },

    'accept': {
        'hosts': ['zzep@vps3.omniscale.nl'],
        'virtualenv': '/home/zzep/www/zzep.online/accept-env',
        'project_root': '/home/zzep/www/zzep.online/accept',
        'static_dir': 'static',
        'code_dir': 'src/backend/web',
        'branch': 'master',
        'origin': 'origin',
        'compress': False,
        'environment': 'accept',
        'uwsgi': True,
        'uwsgi_ini': 'accept',
    },

    'staging': {
        'hosts': ['@vps3.omniscale.nl'],
        'virtualenv': '/home//www/zzep_online.nl/staging-env',
        'project_root': '/home//www/zzep_online.nl/staging',
        'static_dir': 'static',
        'project_dir': 'zzep_online',
        'code_dir': '',
        'branch': 'develop',
        'origin': 'origin',
        'compress': False,
        'environment': 'staging',
    },

}

ANYMAIL = {
    "MANDRILL_API_KEY": 'CF5ElvyoVOa7awSwH4_ozw',
}

DEFAULT_FROM_EMAIL = 'Omniscale <support@omniscale.nl>'
