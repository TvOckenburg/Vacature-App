"""
This is an example settings/local.py file for zzep_online
These settings override what's in settings/base.py
"""

from .base import *

ALLOWED_HOSTS = [
    '*',
]

DATABASES = {
    # 'default': {
    #     'ENGINE': 'django.db.backends.mysql',
    #     'NAME': '',
    #     'USER': '',
    #     'PASSWORD': '',
    #     'HOST': 'localhost',
    #     'PORT': '',
    #     'STORAGE_ENGINE': 'InnoDB',
    #     'OPTIONS': {
    #         'init_command': 'SET character_set_connection=utf8,collation_connection=utf8_unicode_ci'
    #     }
    # },
}

DEBUG = False

TEMPLATES[0]['OPTIONS']['debug'] = DEBUG

# Enable the line below for Mandrill
EMAIL_BACKEND = "anymail.backends.mandrill.EmailBackend"

# Enable the lines below for Sentry
# if not DEBUG:
#
#     import sentry_sdk
#     from sentry_sdk.integrations.django import DjangoIntegration
#
#     sentry_sdk.init(
#         dsn="https://5cfd400a2e224fb4863542e2d9a1055d@sentry.io/1331744",
#         integrations=[DjangoIntegration()]
#     )


