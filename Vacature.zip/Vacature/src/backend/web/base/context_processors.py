from django.conf import settings


def zzep_settings(request):

    return {
        'DEBUG': settings.DEBUG,
        'GA_TRACKING_ID': settings.GA_TRACKING_ID,
    }
