# -*- coding: utf-8 -*-
from django.http import (
    HttpResponse,
    HttpResponseRedirect
)
from django.views.generic.list import ListView
from .models import *
from .forms import *
from django.shortcuts import (
    render,
    render_to_response, redirect
)
from django.utils.translation import ugettext_lazy as _
from django.views.decorators.csrf import csrf_protect
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from django.template import RequestContext

# -*- coding: utf-8 -*-
from django.http import (
    HttpResponse,
    HttpResponseRedirect
)
from django.views.generic.list import ListView
from .models import *
from .forms import *
from django.shortcuts import (
    render,
    render_to_response, redirect
)
from django.utils.translation import ugettext_lazy as _
from django.views.decorators.csrf import csrf_protect
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from django.template import RequestContext


def bad(request):
    """Simulates a server error"""
    1 / 0


@csrf_protect
def vacancy_detail(request):
    form = VacancyForm(request.POST, request.FILES or None)
    if request.method == 'POST':
        if form.is_valid():
            # Placeholder tekst in de plaintext en htmly
            plaintext = get_template('emails/vacancy_detail/email.txt')
            htmly = get_template('emails/vacancy_detail/email.html')

            cv = request.FILES['cv']
            ctx = {'obj': form}
            form.save()

            mail_to = request.POST.get('zzep_email')

            subject, from_email, to = 'Vacature interesse', 'from@example.com', mail_to

            text_content = plaintext.render(ctx)
            html_content = htmly.render(ctx)

            msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
            msg.attach(cv.name, cv.read(), cv.content_type)
            msg.attach_alternative(html_content, "text/html")
            msg.send()

            return HttpResponseRedirect('vacatures/bedankt-pagina')
        else:
            return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
    else:
        return render(request, request.META.get('HTTP_REFERER'), {'form': form})


-
-
- @ csrf_protect
-


def job_offer(request):
    -    form = JobOfferForm(request.POST or None)


-
if request.method == 'POST':
    -
    if form.is_valid():
        -            plaintext = get_template("emails/job_offer/email.txt")
-            htmly = get_template("emails/job_offer/email.html")
-
-            ctx = {'obj': form}
-
-            obj = form.save(commit=False)
-            obj.save()
-
-            mail_to = request.POST.get('zzep_email')
-
-            subject, from_email, to = 'Nieuwe Opdrachtgever', 'from@example.com', mail_to
-            text_content = plaintext.render(ctx)
-            html_content = htmly.render(ctx)
-
-            msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
-            msg.attach_alternative(html_content, 'text/html')
-            msg.send()
-
return HttpResponseRedirect('opdrachtgever/bedankt-pagina')
- else:
-
return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
-
-
return render(request, request.META.get("HTTP_REFERER"), {'form': form})
-
-
- @ csrf_protect
-


def open_application(request):
    -    form = OpenApplicationForm(request.POST, request.FILES or None)


-
if request.method == 'POST':
    -
    if form.is_valid():
        -            plaintext = get_template("emails/open_application/email.txt")
-            htmly = get_template("emails/open_application/email.html")
-
-            cv = request.FILES['cv']
-            ctx = {'obj': form}
-
-            mail_to = request.POST.get('zzep_email')
-
-            subject, from_email, to = 'Vacature interesse', 'from@example.com', mail_to
-            text_content = plaintext.render(ctx)
-            html_content = htmly.render(ctx)
-
-            msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
-            msg.attach(cv.name, cv.read(), cv.content_type)
-            msg.attach_alternative(html_content, "text/html")
-            msg.send()
-
return HttpResponseRedirect('open-sollicitatie/bedankt-pagina')
- else:
-
return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
- else:
-
return render(request, request.META.get('HTTP_REFERER'), {'form': form})