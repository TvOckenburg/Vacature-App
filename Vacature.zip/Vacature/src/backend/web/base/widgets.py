from django import forms
from django.utils.safestring import mark_safe
from django.contrib.auth.hashers import UNUSABLE_PASSWORD_PREFIX
from django.utils.html import format_html
from django.forms.utils import flatatt
from django.utils.translation import ugettext_lazy as _


class DescriptivePasswordFieldWidget(forms.Widget):

    def render(self, name, value, attrs):

        encoded = value
        final_attrs = self.build_attrs(attrs)
        text = _("Wachtwoorden zijn versleuteld opgeslagen en daardoor niet inzichtelijk. "
                 "Aanpassen kan via <a href=\"../password/\">dit formulier</a>.")

        if not encoded or encoded.startswith(UNUSABLE_PASSWORD_PREFIX):
            summary = mark_safe("%s" % _("Geen wachtwoord opgegeven"))
        else:
            summary = mark_safe("%s" % text)

        return format_html("<div{} style=\"padding-top: 6px;\">{}</div>", flatatt(final_attrs), summary)
