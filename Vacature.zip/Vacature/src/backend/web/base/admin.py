# -*- coding: utf-8 -*-
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import AuthUser, Vacancy, JobOffer, OpenApplication, Contact
from .forms import AuthUserCreationForm, AuthUserChangeForm


@admin.register(AuthUser)
class AuthUserAdmin(UserAdmin):
    form = AuthUserChangeForm
    add_form = AuthUserCreationForm
    list_display = ('email', 'first_name', 'last_name',)
    ordering = ('email',)
    search_fields = ('email', 'first_name', 'last_name')
    readonly_fields = ('creation_date', 'modification_date', 'last_login',)
    list_filter = ('is_active',)

    filter_horizontal = ('groups', 'user_permissions')

    def get_list_display(self, request):

        if request.user.is_superuser:
            return ['email', 'first_name', 'last_name', 'is_active', 'is_staff', 'is_superuser']
        else:
            return ['email', 'first_name', 'last_name', 'is_active', ]

    fieldsets = (
        (
            None, {
                'classes': ('wide',),
                'fields': ('email', 'password')
            }
        ),
        (
            'Persoonlijke gegevens', {
                'classes': ('wide',),
                'fields': ('first_name', 'last_name', 'telephone_number')
            },
        ),
        (
            'Datum en tijd', {
                'classes': ('wide',),
                'fields': ('creation_date', 'modification_date', 'last_login',)
            }
        ),
        (
            'Rechten', {
                'classes': ('wide',),
                'fields': ('is_active', 'is_staff', 'is_superuser')
            }
        ),
        (
            'Gebruikerrechten', {
                'classes': (),
                'fields': ('groups', 'user_permissions',)
            }
        ),
    )

    add_fieldsets = (
        (
            None, {
                'classes': ('wide',),
                'fields': ('email', 'password1', 'password2', 'is_staff', 'is_superuser')
            }
        ),
    )

    def get_fieldsets(self, request, obj=None):

        if not obj:
            return self.add_fieldsets

        return self.fieldsets


@admin.register(Vacancy)
class VacancyAdmin(admin.ModelAdmin):
    pass


@admin.register(JobOffer)
class JobOfferAdmin(admin.ModelAdmin):
    pass


@admin.register(OpenApplication)
class OpenApplicationAdmin(admin.ModelAdmin):
    pass


@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ['last_name', 'insertion', 'first_name', 'question', 'contact_method']
