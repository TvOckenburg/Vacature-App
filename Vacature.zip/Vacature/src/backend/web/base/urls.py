from . import views

from django.conf.urls import url, handler404, handler500

urlpatterns = [
]


