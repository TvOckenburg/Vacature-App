# # -*- coding: utf-8 -*-
from django.http import HttpResponse, HttpResponseRedirect
from django.db import models
from django.conf import settings
from django.utils.translation import ugettext_lazy as _
from django.views.decorators.csrf import csrf_protect
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from django.template import RequestContext
from django.dispatch import receiver
from django.db.models.signals import post_save
from django.contrib.auth.models import (
    AbstractBaseUser,
    PermissionsMixin,
)

from .managers import AuthUserManager

from wagtail.admin.edit_handlers import StreamFieldPanel, MultiFieldPanel, FieldPanel, TabbedInterface, ObjectList
from wagtail.core.models import Page
from wagtail.core.fields import StreamField, RichTextField
from wagtail.core import blocks
from wagtail.images.blocks import ImageChooserBlock
from wagtail.images.edit_handlers import ImageChooserPanel
from wagtail.contrib.settings.models import BaseSetting, register_setting


class TimestampedModel(models.Model):
    creation_date = models.DateTimeField(_("Aangemaakt op"),
                                         auto_now_add=True)

    modification_date = models.DateTimeField(_("Aangepast op"),
                                             auto_now=True)

    class Meta:
        abstract = True


# MODELS


class AuthUser(AbstractBaseUser, TimestampedModel, PermissionsMixin):
    """
    Custom UserModel so we can force the use of the emailaddress to login on ZZEP

    Additionally:
     - We added the field that keeps track of the last modification date of the password
    """

    email = models.EmailField(
        verbose_name=_("Emailadres"),
        max_length=255,
        unique=True,
    )

    first_name = models.CharField(_("Voornaam"),
                                  default='',
                                  max_length=100)

    last_name = models.CharField(_("Achternaam"),
                                 default='',
                                 max_length=100)

    telephone_number = models.CharField(_("Telefoonnummer"),
                                        default='',
                                        max_length=100,
                                        blank=True,
                                        null=True)

    is_active = models.BooleanField(_("Is actief"),
                                    default=True)

    is_staff = models.BooleanField(_("Is beheerder"),
                                   default=False)

    password_changed_date = models.DateTimeField(_("Wachtwoord aangepast"),
                                                 blank=True,
                                                 auto_now_add=True)

    objects = AuthUserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = list()

    def get_full_name(self):
        return str(self)

    def get_short_name(self):
        return str(self.first_name)

    def __str__(self):
        return self.first_name if self.first_name else '-'

    class Meta:
        verbose_name = _("Gebruiker")
        verbose_name_plural = _("Gebruikers")


@register_setting
class ContactCenter(BaseSetting):
    phone_number = models.CharField(blank=True,
                                    null=True,
                                    max_length=32,
                                    verbose_name=_('telefoonnummer'),
                                    help_text=_(
                                        "Het telefoonnummer van ZZEP met +31 en GEEN leestekens zoals spaties of streepjes."))

    phone_description = models.CharField(blank=True,
                                         null=True,
                                         max_length=32,
                                         verbose_name=_('telefoon descriptie'),
                                         help_text=_(
                                             "Het telefoonnummer van ZZEP die prettig leesbaar is voor de gebruiker."))

    whatsapp_number = models.CharField(blank=True,
                                       verbose_name=_('Whatsapp nummer'),
                                       null=True,
                                       max_length=32,
                                       help_text=_(
                                           "Het Whatsapp nummer van ZZEP met +31 en GEEN leestekens zoals spaties of streepjes."))

    whatsapp_description = models.CharField(blank=True,
                                            null=True,
                                            max_length=32,
                                            verbose_name=_('Whatsapp descriptie'),
                                            help_text=_(
                                                'Het Whatsapp nummer van ZZEP die prettig leesbaar is voor de gebruiker.'))

    e_mail = models.CharField(blank=True,
                              null=True,
                              verbose_name=_('E-mail adres'),
                              max_length=64,
                              help_text=_("Het e-mail address waarmee mensen contact kunnen opnemen met uw bedrijf.."))

    facebook = models.URLField(blank=True,
                               null=True,
                               verbose_name=_('facebook'),
                               help_text=_(
                                   "De link van uw bedrijf's Facebookpagina. Bijvoorbeeld: https://nl-nl.facebook.com/ZZEP"))

    linkedin = models.URLField(blank=True,
                               null=True,
                               verbose_name=_('linkedin'),
                               help_text=_(
                                   "De link van uw bedrijf's LinkedIn account. Bijvoorbeeld: https://nl.linkedin.com/ZZEP"))

    twitter = models.URLField(blank=True,
                              null=True,
                              verbose_name=_('twitter'),
                              help_text=_(
                                  "De link van uw bedrijf's Twitter account. Bijvoorbeeld https://twitter.com/ZZEP"))

    instagram = models.URLField(blank=True,
                                null=True,
                                verbose_name=_('instagram'),
                                help_text=_(
                                    "De link van uw  instagram account. Bijvoorbeeld https://www.instagram.com/ZZEP"))

    panels = [
        MultiFieldPanel([
            FieldPanel('phone_number'),
            FieldPanel('phone_description'),
            FieldPanel('whatsapp_number'),
            FieldPanel('whatsapp_description'),
            FieldPanel('e_mail'),
        ], heading=_("Algemeen contact")),
        MultiFieldPanel([
            FieldPanel('facebook'),
            FieldPanel('linkedin'),
            FieldPanel('twitter'),
            FieldPanel('instagram'),
        ], heading=_("Social media")),
    ]

    class Meta:
        verbose_name = _('Contact informatie')


class OpenApplicationBlock(blocks.StructBlock):

    title = blocks.CharBlock(verbose_name=_("Titel"),
                             required=False,
                             blank=True,
                             default='')

    text = blocks.RichTextBlock(verbose_name=_("Tekst"),
                                features=[
                                    'bold', 'italic', 'h2', 'h3', 'h4', 'h5', 'ol', 'ul', 'link'
                                ],
                                required=False,
                                blank=True,
                                default='')

    label = blocks.CharBlock(required=False,
                             label=_('label'),
                             help_text=_('LET OP: Label en URL moeten ingevuld zijn om de knop te kunnen publiceren!'))

    url = blocks.TextBlock(required=False,
                           label=_('link'),
                           help_text=_(
                               'LET OP: Label en URL moeten ingevuld zijn om de knop te kunnen publiceren! Voorbeeld: vacature-plaatsen'))

    class Meta:
        verbose_name = _('Open sollicitatie')
        label = _('Open sollicitatie')
        template = 'blocks/open_application_block.html'
        icon = 'tick-inverse'


class ButtonBlock(blocks.StructBlock):
    label = blocks.CharBlock(required=False,
                             label=_('label'),
                             help_text=_('LET OP: Label en URL moeten ingevuld zijn om de knop te kunnen publiceren!'))

    url = blocks.TextBlock(required=False,
                           label=_('link'),
                           help_text=_(
                               'LET OP: Label en URL moeten ingevuld zijn om de knop te kunnen publiceren! Voorbeeld: vacature-plaatsen'))

    class Meta:
        verbose_name = _('Knoppen')
        label = _('Knop')
        template = 'blocks/button.html'
        icon = 'tick-inverse'


class ImageBlock(blocks.StructBlock):
    image = ImageChooserBlock(required=False,
                              label=_("Afbeelding"),
                              help_text=_("*Optioneel* De breedte van een afbeelding moet minimaal 640 pixels zijn."))

    position_image = blocks.ChoiceBlock(choices=[
        ('left', _('links')),
        ('right', _('rechts'))
    ],
        icon='cup',
        required=False,
        help_text=_("*Optioneel* Bepaalt of de foto op de linkerkant van een pagina staat of aan de rechterkant"),
        label=_("Afbeelding positie"),
        default='left')

    class Meta:
        verbose_name = _('Afbeelding')
        label = _('Afbeelding')
        template = 'blocks/image.html'
        icon = 'image'


class TextImageBlock(blocks.StructBlock):
    title = blocks.CharBlock(required=False,
                             classname="title",
                             label=_("Titel"))

    text = blocks.RichTextBlock(required=False,
                                label=_("Tekst"),
                                features=[
                                    'bold', 'italic', 'h2', 'h3', 'h4', 'h5', 'ol', 'ul', 'link'
                                ])
    imageblock = ImageBlock()

    button = ButtonBlock()

    panels = [
        FieldPanel('title'),
        FieldPanel('text'),
        StreamFieldPanel('imageblock'),
        StreamFieldPanel('button'),
    ]

    class Meta:
        verbose_name = _(
            'tekst met optionele plaatje | Om tekst op deze pagina te zetten met eventeel een afbeelding naast de tekst')
        label = _('Tekst met optionele afbeelding')

        icon = 'form'
        template = 'blocks/text_image.html'


class ContactBlock(blocks.StructBlock):
    title = blocks.CharBlock(required=False,
                             help_text=_(
                                 'Contact informatie (zoals Whatsapp) word uit Contact informatie getoond en hoeft hier niet ingevuld te worden.'),
                             label=_("Titel"))

    class Meta:
        verbose_name = _('Contact Informatie')
        label = _('Contact informatie')
        icon = 'mail'
        template = 'blocks/contact.html'


class MapBlock(blocks.StructBlock):
    title = blocks.CharBlock(required=False,
                             help_text=_('Geeft ook een kaart weer met de locatie van ZZEP'),
                             label=_("Titel"))

    google_map_url = blocks.URLBlock(_("Google map"),
                                     null=True,
                                     blank=True)

    class Meta:
        verbose_name = _('Kaart')
        label = _('Kaart')
        icon = 'image'
        template = 'blocks/map.html'


class GenericPage(Page):
    body = StreamField([
        ('text', TextImageBlock()),
        # ('column_block', blocks.ListBlock(
        #     TextImageBlock(),
        #     label=_('Kolommen'),
        #     icon='grip',
        # )),
        ('contact_block', ContactBlock()),
        ('image', blocks.ListBlock(
            ImageBlock(),
            label=_('Afbeeldingen'),
            icon='image'
        )),
        ('button', blocks.ListBlock(
            ButtonBlock(),
            template='blocks/buttons.html',
            label=_('Knoppen'),
            icon='tick-inverse',
        )),
    ])

    sidebar = StreamField([
        ('text', TextImageBlock()),
        ('contact_block', ContactBlock()),
        ('open_application_block', OpenApplicationBlock()),
    ], blank=True, null=True)

    content_panels = Page.content_panels + [
        StreamFieldPanel('body'),
    ]

    sidebar_panels = [
        StreamFieldPanel('sidebar'),
    ]

    edit_handler = TabbedInterface([
        ObjectList(content_panels, heading='Content'),
        ObjectList(sidebar_panels, heading='Sidebar'),
        ObjectList(Page.promote_panels, heading='Promote'),
        ObjectList(Page.settings_panels, heading='Settings', classname="settings"),
    ])

    template = "home.html"

    subpage_types = ['GenericPage', 'VacancyOverviewPage', 'PlaceJobOfferPage', 'OpenApplicationPage', 'ContactPage']

    class Meta:
        verbose_name = _("Generieke pagina | om de homepage of opdrachtgever pagina te maken")
        verbose_name_plural = _("Generieke pagina's")


class VacancyDetailPage(Page):
    min_hours_per_week = models.IntegerField(verbose_name=_("Minimale uren per week"))

    max_hours_per_week = models.IntegerField(verbose_name=_("Maximale uren per week"),
                                             null=True,
                                             blank=True)

    min_years_experience = models.IntegerField(verbose_name=("Minimale aantal jaren werk ervaring"))

    max_years_experience = models.IntegerField(verbose_name=_("Maximale aantal jaren werk ervaring"),
                                               null=True,
                                               blank=True)

    education_level = models.CharField(verbose_name=_("Opleidingsniveau voor een vacature"),
                                       max_length=100)

    area = models.CharField(verbose_name=_("Omgeving"),
                            max_length=255)

    reference_number = models.CharField(max_length=255,
                                        verbose_name=_("Referentienummer"),
                                        null=True,
                                        blank=True)

    function_description = RichTextField(verbose_name=_("Functie omschrijving"),
                                         features=[
                                             'bold', 'italic', 'h2', 'h3', 'h4', 'h5', 'ol', 'ul', 'link'
                                         ])

    function_demands = RichTextField(verbose_name=_("Functie eisen"),
                                     features=[
                                         'bold', 'italic', 'h2', 'h3', 'h4', 'h5', 'ol', 'ul', 'link'
                                     ])

    function_offerings = RichTextField(verbose_name=_("Wat wij bieden"),
                                       features=[
                                           'bold', 'italic', 'h2', 'h3', 'h4', 'h5', 'ol', 'ul', 'link'
                                       ])

    sidebar = StreamField([
        ('text', TextImageBlock()),
        ('contact_block', ContactBlock()),
        ('google_map_block', MapBlock()),
    ], blank=True, null=True)

    content_panels = Page.content_panels + [
        MultiFieldPanel([
            FieldPanel('min_hours_per_week'),
            FieldPanel('max_hours_per_week'),
            FieldPanel('min_years_experience'),
            FieldPanel('max_years_experience'),
            FieldPanel('education_level'),
            FieldPanel('area'),
        ]),
        MultiFieldPanel([
            FieldPanel('function_description'),
            FieldPanel('function_demands'),
            FieldPanel('function_offerings'),
        ])
    ]

    sidebar_panels = [
        StreamFieldPanel('sidebar'),
    ]

    edit_handler = TabbedInterface([
        ObjectList(content_panels, heading='Content'),
        ObjectList(sidebar_panels, heading='Sidebar'),
        ObjectList(Page.promote_panels, heading='Promote'),
        ObjectList(Page.settings_panels, heading='Settings', classname="settings"),
    ])

    template = "vacancy_detail_page.html"

    parent_page_type = []

    subpage_types = []

    def get_context(self, request, *args, **kwargs):
        context = super(VacancyDetailPage, self).get_context(request, *args, **kwargs)

        # Contact form must be imported in this def for models is already being imported in forms.py, but we want to load in a specific model here anyway
        from .forms import VacancyForm

        form = VacancyForm(request.POST or None, request.FILES or None)

        context['form'] = form

        return context

    def serve(self, request, *args, **kwargs):

        if request.method == 'POST':

            context = self.get_context(request, *args, **kwargs)

            form = context.get('form')

            if form.is_valid():

                zzep_settings = ContactCenter.objects.first()

                obj = form.save()

                plaintext = get_template("emails/vacancy_detail/email.txt")
                html = get_template("emails/vacancy_detail/email.html")

                confirm_plaintext = get_template("emails/vacancy_detail/confirm.txt")
                confirm_html = get_template("emails/vacancy_detail/confirm.html")

                ctx = {
                    'obj': obj,
                    'url': request.build_absolute_uri
                }

                from_email = settings.DEFAULT_FROM_EMAIL

                text_content = plaintext.render(ctx)
                html_content = html.render(ctx)

                confirm_text_content = confirm_plaintext.render(ctx)
                confirm_html_content = confirm_html.render(ctx)

                msg = EmailMultiAlternatives(_("Vacature interesse"), text_content, from_email, [zzep_settings.e_mail])
                msg.attach_alternative(html_content, 'text/html')
                msg.send()

                confirm_msg = EmailMultiAlternatives(_("Bevestiging sollicitatie"), confirm_text_content, from_email,
                                                     [obj.email])
                confirm_msg.attach_alternative(confirm_html_content, 'text/html')
                confirm_msg.send()

                confirm = self.get_parent().get_siblings().live().type(ConfirmPage).first()

                if confirm:
                    return HttpResponseRedirect(confirm.url)
                else:
                    return HttpResponseRedirect(self.url)

        return super(VacancyDetailPage, self).serve(request, *args, **kwargs)

    class Meta:
        verbose_name = _("Vacature detail pagina | Hier plaats je een vacature")
        verbose_name_plural = _("Vacature detail pagina's")


class VacancyOverviewPage(Page):
    introduction = RichTextField(verbose_name=_("Introductie tekst"),
                                 features=[
                                     'bold', 'italic', 'h2', 'h3', 'h4', 'h5', 'ol', 'ul', 'link'
                                 ])

    sidebar = StreamField([
        ('open_application_block', OpenApplicationBlock()),
    ], blank=True, null=True)

    sidebar_panels = [
        StreamFieldPanel('sidebar'),
    ]

    content_panels = Page.content_panels + [
        FieldPanel('introduction')
    ]

    edit_handler = TabbedInterface([
        ObjectList(content_panels, heading='Content'),
        ObjectList(sidebar_panels, heading='Sidebar'),
        ObjectList(Page.promote_panels, heading='Promote'),
        ObjectList(Page.settings_panels, heading='Settings', classname="settings"),
    ])

    template = "vacancy_overview_page.html"

    subpage_types = ['BranchPage', 'ConfirmPage']

    def get_context(self, request, *args, **kwargs):
        context = super().get_context(request, *args, **kwargs)
        context['child_pages'] = context['page'].get_children().type(BranchPage).live
        return context

    class Meta:
        verbose_name = _("Vacature overzicht pagina | is een pagina om alle branches onder te zetten.")
        verbose_name_plural = _("Vacature overzicht pagina's")


class BranchPage(Page):
    intro_text = RichTextField(
        null=True,
        blank=True
    )

    content_panels = Page.content_panels + [
        FieldPanel('intro_text'),
    ]

    template = "branch_detail_page.html"
    parent_page_type = ['VacancyOverviewPage']
    subpage_types = ['VacancyDetailPage']

    def get_context(self, request, *args, **kwargs):
        context = super().get_context(request, *args, **kwargs)
        context['vacancies'] = self.get_children().filter(live=True)
        return context

    class Meta:
        verbose_name = _("Branche pagina | Voor het aankoppelen van onderliggende vacatures.")
        verbose_name_plural = _("Branche pagina's")


class PlaceJobOfferPage(Page):
    template = 'place_job_offer.html'

    body = StreamField([
        ('text', TextImageBlock()),
        # ('column_block', blocks.ListBlock(
        #     TextImageBlock(),
        #     label=_('Kolommen'),
        #     icon='grip',
        # )),
        ('contact_block', ContactBlock()),
        ('image', blocks.ListBlock(
            ImageBlock(),
            label=_('Afbeeldingen'),
            icon='image'
        )),
        ('button', blocks.ListBlock(
            ButtonBlock(),
            template='blocks/buttons.html',
            label=_('Knoppen'),
            icon='tick-inverse',
        )),
    ])

    sidebar = StreamField([
        ('text', TextImageBlock()),
        ('contact_block', ContactBlock()),
    ], blank=True, null=True)

    content_panels = Page.content_panels + [
        StreamFieldPanel('body'),
    ]

    sidebar_panels = [
        StreamFieldPanel('sidebar'),
    ]

    edit_handler = TabbedInterface([
        ObjectList(content_panels, heading='Content'),
        ObjectList(sidebar_panels, heading='Sidebar'),
        ObjectList(Page.promote_panels, heading='Promote'),
        ObjectList(Page.settings_panels, heading='Settings', classname="settings"),
    ])

    parent_page_types = ['GenericPage']

    subpage_types = ['ConfirmPage']

    def get_context(self, request, *args, **kwargs):

        context = super().get_context(request, *args, **kwargs)

        # Contact form must be imported in this def for models is already being imported in forms.py, but we want to load in a specific model here anyway
        from .forms import JobOfferForm

        form = JobOfferForm(request.POST or None)

        context['form'] = form

        return context

    def serve(self, request, *args, **kwargs):

        if request.method == 'POST':

            context = self.get_context(request, *args, **kwargs)

            form = context.get('form')

            if form.is_valid():

                zzep_settings = ContactCenter.objects.first()

                obj = form.save()

                plaintext = get_template("emails/job_offer/email.txt")
                html = get_template("emails/job_offer/email.html")

                confirm_plaintext = get_template("emails/job_offer/confirm.txt")
                confirm_html = get_template("emails/job_offer/confirm.html")

                ctx = {
                    'obj': obj
                }

                from_email = settings.DEFAULT_FROM_EMAIL

                text_content = plaintext.render(ctx)
                html_content = html.render(ctx)

                confirm_text_content = confirm_plaintext.render(ctx)
                confirm_html_content = confirm_html.render(ctx)

                msg = EmailMultiAlternatives(_('Nieuwe Opdrachtgever'), text_content, from_email,
                                             [zzep_settings.e_mail])
                msg.attach_alternative(html_content, 'text/html')
                msg.send()

                confirm_msg = EmailMultiAlternatives(_("Bevestiging personeels aanvraag"), confirm_text_content,
                                                     from_email, [obj.email])
                confirm_msg.attach_alternative(confirm_html_content, 'text/html')
                confirm_msg.send()

                confirm = self.get_children().live().type(ConfirmPage).first()

                if confirm:
                    return HttpResponseRedirect(confirm.url)
                else:
                    return HttpResponseRedirect(self.url)

        return super().serve(request, *args, **kwargs)

    class Meta:
        verbose_name = _("Vacature plaatsen pagina | Hier doen werkgevers de aanvraag om een vacature te plaatsen.")
        verbose_name_plural = _("Vacature plaatsen pagina's")


class OpenApplicationPage(Page):
    template = 'open_application.html'

    body = StreamField([
        ('text', TextImageBlock()),
        # ('column_block', blocks.ListBlock(
        #     TextImageBlock(),
        #     label=_('Kolommen'),
        #     icon='grip',
        # )),
        ('contact_block', ContactBlock()),
        ('image', blocks.ListBlock(
            ImageBlock(),
            label=_('Afbeeldingen'),
            icon='image',
            classname='full'
        )),
        ('button', blocks.ListBlock(
            ButtonBlock(),
            template='blocks/buttons.html',
            label=_('Knoppen'),
            icon='tick-inverse',
        )),
    ])
    sidebar = StreamField([
        ('text', TextImageBlock()),
        ('contact_block', ContactBlock()),
    ], blank=True, null=True)

    content_panels = Page.content_panels + [
        StreamFieldPanel('body'),
    ]

    sidebar_panels = [
        StreamFieldPanel('sidebar'),
    ]

    edit_handler = TabbedInterface([
        ObjectList(content_panels, heading='Content'),
        ObjectList(sidebar_panels, heading='Sidebar'),
        ObjectList(Page.promote_panels, heading='Promote'),
        ObjectList(Page.settings_panels, heading='Settings', classname="settings"),
    ])

    subpage_types = ['ConfirmPage']

    def get_context(self, request, *args, **kwargs):

        context = super().get_context(request, *args, **kwargs)

        # Contact form must be imported in this def for models is already being imported in forms.py, but we want to load in a specific model here anyway
        from .forms import OpenApplicationForm

        form = OpenApplicationForm(request.POST or None, request.FILES or None)

        context['form'] = form

        return context

    def serve(self, request, *args, **kwargs):

        if request.method == 'POST':

            context = self.get_context(request, *args, **kwargs)

            form = context.get('form')

            if form.is_valid():

                zzep_settings = ContactCenter.objects.first()

                obj = form.save()

                plaintext = get_template("emails/open_application/email.txt")
                html = get_template("emails/open_application/email.html")

                confirm_plaintext = get_template("emails/open_application/confirm.txt")
                confirm_html = get_template("emails/open_application/confirm.html")

                cv = obj.cv

                ctx = {
                    'obj': obj
                }

                from_email = settings.DEFAULT_FROM_EMAIL

                text_content = plaintext.render(ctx)
                html_content = html.render(ctx)

                confirm_text_content = confirm_plaintext.render(ctx)
                confirm_html_content = confirm_html.render(ctx)

                msg = EmailMultiAlternatives(_("Vacature interesse"), text_content, from_email, [zzep_settings.e_mail])
                msg.attach_file(cv.path)
                msg.attach_alternative(html_content, "text/html")
                msg.send()

                confirm_msg = EmailMultiAlternatives(_("Bevestiging open sollicitatie"), confirm_text_content,
                                                     from_email, [obj.email])
                confirm_msg.attach_alternative(confirm_html_content, 'text/html')
                confirm_msg.send()

                confirm = self.get_children().live().type(ConfirmPage).first()

                if confirm:

                    return HttpResponseRedirect(confirm.url)
                else:
                    return HttpResponseRedirect(self.url)

        return super().serve(request, *args, **kwargs)

    class Meta:
        verbose_name = _("Open sollicitatie pagina | Hier kunnen de werknemers/werkelozen open sollicitaties invullen.")
        verbose_name_plural = _("Open sollicitatie pagina's")


class ContactPage(Page):
    template = 'contact.html'

    body = StreamField([
        ('text', TextImageBlock()),
        # ('column_block', blocks.ListBlock(
        #     TextImageBlock(),
        #     label=_('Kolommen'),
        #     icon='grip',
        # )),
        ('contact_block', ContactBlock()),
        ('image', blocks.ListBlock(
            ImageBlock(),
            label=_('Afbeeldingen'),
            icon='image'
        )),
        ('button', blocks.ListBlock(
            ButtonBlock(),
            template='blocks/buttons.html',
            label=_('Knoppen'),
            icon='tick-inverse',
        )),
    ])

    sidebar = StreamField([
        ('text', TextImageBlock()),
        ('contact_block', ContactBlock()),
        ('google_map_block', MapBlock()),
    ], blank=True, null=True)

    content_panels = Page.content_panels + [
        StreamFieldPanel('body'),
    ]

    sidebar_panels = [
        StreamFieldPanel('sidebar'),
    ]

    edit_handler = TabbedInterface([
        ObjectList(content_panels, heading='Content'),
        ObjectList(sidebar_panels, heading='Sidebar'),
        ObjectList(Page.promote_panels, heading='Promote'),
        ObjectList(Page.settings_panels, heading='Settings', classname="settings"),
    ])

    parent_page_types = ['GenericPage']

    subpage_types = ['ConfirmPage']

    def get_context(self, request, *args, **kwargs):

        context = super().get_context(request, *args, **kwargs)

        # Contact form must be imported in this def for models is already being imported in forms.py, but we want to load in a specific model here anyway
        from .forms import ContactForm

        form = ContactForm(request.POST or None)

        context['form'] = form

        return context

    def serve(self, request, *args, **kwargs):

        if request.method == 'POST':

            context = self.get_context(request, *args, **kwargs)

            form = context.get('form')

            if form.is_valid():

                zzep_settings = ContactCenter.objects.first()

                obj = form.save()

                plaintext = get_template("emails/contact/email.txt")
                html = get_template("emails/contact/email.html")

                confirm_plaintext = get_template("emails/contact/confirm.txt")
                confirm_html = get_template("emails/contact/confirm.html")

                ctx = {
                    'obj': obj
                }

                from_email = settings.DEFAULT_FROM_EMAIL

                text_content = plaintext.render(ctx)
                html_content = html.render(ctx)

                confirm_text_content = confirm_plaintext.render(ctx)
                confirm_html_content = confirm_html.render(ctx)

                msg = EmailMultiAlternatives(_('Contactverzoek'), text_content, from_email, [zzep_settings.e_mail])
                msg.attach_alternative(html_content, 'text/html')
                msg.send()

                confirm_msg = EmailMultiAlternatives(_("Bevestiging contact verzoek"), confirm_text_content, from_email,
                                                     [obj.email])
                confirm_msg.attach_alternative(confirm_html_content, 'text/html')
                confirm_msg.send()

                confirm = self.get_children().live().type(ConfirmPage).first()

                if confirm:
                    return HttpResponseRedirect(confirm.url)
                else:
                    return HttpResponseRedirect(self.url)

        return super().serve(request, *args, **kwargs)

    class Meta:
        verbose_name = _(
            "Contact pagina | Op deze pagina komen de contactgegevens en mischien verduidelijkende tekst voor bij het contact formulier onderaan de pagina.")
        verbose_name_plural = _("Contact pagina's")


class ConfirmPage(Page):
    body = StreamField([
        ('text', TextImageBlock()),
        # ('column_block', blocks.ListBlock(
        #     TextImageBlock(),
        #     label=_('Kolommen'),
        #     icon='grip',
        # )),
        ('contact_block', ContactBlock()),
        ('image', blocks.ListBlock(
            ImageBlock(),
            label=_('Afbeeldingen'),
            icon='image'
        )),
        ('button', blocks.ListBlock(
            ButtonBlock(),
            template='blocks/buttons.html',
            label=_('Knoppen'),
            icon='tick-inverse',
        )),
    ])

    sidebar = StreamField([
        ('text', TextImageBlock()),
        ('contact_block', ContactBlock()),
    ], blank=True, null=True)

    content_panels = Page.content_panels + [
        StreamFieldPanel('body'),
    ]

    sidebar_panels = [
        StreamFieldPanel('sidebar'),
    ]

    edit_handler = TabbedInterface([
        ObjectList(content_panels, heading='Content'),
        ObjectList(sidebar_panels, heading='Sidebar'),
        ObjectList(Page.promote_panels, heading='Promote'),
        ObjectList(Page.settings_panels, heading='Settings', classname="settings"),
    ])

    template = "confirm_page.html"

    parent_page_types = ['GenericPage', 'VacancyOverviewPage', 'PlaceJobOfferPage', 'OpenApplicationPage',
                         'ContactPage']
    subpage_types = ['ContactPage']

    class Meta:
        verbose_name = _(
            "Bevestigings pagina | Nadat een formulier is ingevuld wordt de gebruiker naar de bedankt pagina gebracht.")
        verbose_name_plural = _("Bevestigings pagina's")

    @classmethod
    def can_create_at(cls, parent):
        # Only create one instance of ConfirmPage
        return super(ConfirmPage, cls).can_create_at(parent) and not parent.get_children().type(ConfirmPage)


class Vacancy(models.Model):
    first_name = models.CharField(max_length=100,
                                  verbose_name=_('Voornaam'),
                                  blank=False,
                                  default="")

    insertion = models.CharField(max_length=15,
                                 verbose_name=_('Tussenvoegsel'),
                                 blank=True,
                                 null=True)

    last_name = models.CharField(max_length=100,
                                 verbose_name=_('Achternaam'),
                                 blank=False,
                                 default="")

    email = models.EmailField(max_length=254,
                              blank=False,
                              verbose_name=_('E-mail adres'),
                              default="")

    number = models.CharField(max_length=15,
                              blank=False,
                              verbose_name=_('Telefoonnummer'),
                              default="")

    cv = models.FileField(upload_to='uploads',
                          verbose_name=_('Curriculum Vita"'),
                          max_length=254)

    branch_pk = models.ForeignKey('BranchPage',
                                  on_delete=models.CASCADE)

    vacancy = models.CharField(max_length=254,
                               blank=False,
                               verbose_name=_('Vacature'),
                               default="")

    reference_number = models.CharField(max_length=20,
                                        blank=False,
                                        verbose_name=_('Referentienummer'),
                                        default="")

    branch = models.CharField(max_length=60,
                              blank=False,
                              verbose_name=_('branche'),
                              default="")

    education_level = models.CharField(max_length=60,
                                       blank=False,
                                       verbose_name=_("opleidingsniveau"),
                                       default="")

    def __str__(self):
        return " ".join([self.first_name, self.last_name])

    class Meta:
        verbose_name = _("Vacature")

        verbose_name_plural = _("Vacature's")


class JobOffer(models.Model):
    company_name = models.CharField(verbose_name=_("Bedrijfsnaam"),
                                    max_length=254,
                                    blank=False,
                                    default="")

    contact_person = models.CharField(verbose_name=_("Contact persoon"),
                                      max_length=254,
                                      blank=False,
                                      default="")

    phone_number = models.CharField(verbose_name=_("Telefoonnummer"),
                                    max_length=15,
                                    blank=False,
                                    default="")

    location = models.CharField(verbose_name=_("Plaats"),
                                max_length=254,
                                blank=False,
                                default="")

    crew_request = models.TextField(verbose_name=_("Uw personeelsaanvraag"),
                                    max_length=254,
                                    blank=False,
                                    default="")

    email = models.EmailField(verbose_name=_("E-mailadres"),
                              max_length=254,
                              blank=False,
                              default="")

    def __str__(self):
        return " ".join([self.company_name, self.contact_person])

    class Meta:
        verbose_name = _("Opdrachtgever")

        verbose_name_plural = _("Opdrachtgevers")


class OpenApplication(models.Model):
    first_name = models.CharField(verbose_name=_("Voornaam"),
                                  max_length=60,
                                  blank=False,
                                  default="")

    insertion = models.CharField(verbose_name=_("Tussenvoegsel"),
                                 max_length=15,
                                 blank=True,
                                 null=True)

    last_name = models.CharField(verbose_name=_("Achternaam"),
                                 max_length=60,
                                 blank=False,
                                 default="")

    phone_number = models.CharField(verbose_name=_("Telefoonnummer"),
                                    max_length=15,
                                    blank=False,
                                    default="")

    email = models.EmailField(verbose_name=_("E-mailadres"),
                              max_length=254,
                              blank=False,
                              default="")

    cv = models.FileField(verbose_name=_("Curriculum Vita"),
                          upload_to="uploads",
                          max_length=254,
                          blank=False,
                          default="")

    reference = models.CharField(verbose_name=_("Hoe bent u hier gekomen"),
                                 max_length=254,
                                 null=True,
                                 blank=True)

    def __str__(self):
        return " ".join([self.first_name, self.last_name])

    class Meta:
        verbose_name = _("Open sollicitatie")
        verbose_name_plural = _("Open sollicitaties")


class Contact(models.Model):
    QUESTION_OPTIONS = (
        ('personel', _("Personeel")),
        ('work', _("Werk")),
        ('other', _("Overig...")),
    )

    CONTACT_OPTIONS = (
        ('telefoon', _("Telefoon")),
        ('email', _("E-mail")),
        ('whatsapp', _("Whatsapp")),
    )

    first_name = models.CharField(verbose_name=_("Voornaam"),
                                  max_length=60,
                                  blank=False,
                                  default="")

    insertion = models.CharField(verbose_name=_("Tussenvoegsel"),
                                 max_length=15,
                                 blank=True,
                                 default="")

    last_name = models.CharField(verbose_name=_("Achternaam"),
                                 max_length=60,
                                 blank=False,
                                 default="")

    phone_number = models.CharField(verbose_name=_("Telefoonnummer"),
                                    max_length=15,
                                    blank=False,
                                    default="")

    email = models.EmailField(verbose_name=_("E-mailadres"),
                              max_length=254,
                              blank=False,
                              default="")

    city = models.CharField(verbose_name=_("Stad"),
                            max_length=60,
                            blank=False,
                            default="")

    question = models.CharField(verbose_name=_("Vraag over"),
                                choices=QUESTION_OPTIONS,
                                default=QUESTION_OPTIONS[0][0],
                                max_length=9,
                                null=True,
                                blank=True)

    contact_method = models.CharField(verbose_name=_("Contactmethode"),
                                      max_length=8,
                                      choices=CONTACT_OPTIONS,
                                      default=CONTACT_OPTIONS[0][0],
                                      null=True,
                                      blank=True)

    def __str__(self):
        return " ".join([self.first_name, self.last_name])

    class Meta:
        verbose_name = _("Contact")
        verbose_name_plural = _("Contact")


@receiver(post_save, sender=VacancyDetailPage)
def create_reference_number(sender, instance, created, **kwargs):
    if created:
        instance.reference_number = "ZZEP%06d" % instance.pk
        instance.save()
