import os
import json
from django.conf import settings
from django.template.defaulttags import register


@register.assignment_tag(takes_context=True)
def get_site_root(context):
    # NB this returns a core.Page, not the implementation-specific model used
    # so object-comparison to self will return false as objects would differ
    return context['request'].site.root_page


def has_menu_children(page):
    return page.get_children().live().in_menu().exists()


# Retrieves the top menu items - the immediate children of the parent page
# The has_menu_children method is necessary because the bootstrap menu requires
# a dropdown class to be applied to a parent
@register.inclusion_tag('tags/menu.html', takes_context=True)
def menu(context, parent, calling_page=None):
    menuitems = parent.get_children().filter(
        live=True,
        show_in_menus=True
    )
    for menuitem in menuitems:
        menuitem.show_dropdown = has_menu_children(menuitem)
    return {
        'calling_page': calling_page,
        'menuitems': menuitems,
        # required by the pageurl tag that we want to use within this template
        'request': context['request'],
    }


# Retrieves the children of the top menu items for the drop downs
@register.inclusion_tag('tags/menu_children.html', takes_context=True)
def menu_children(context, parent):
    menuitems_children = parent.get_children()
    menuitems_children = menuitems_children.live().in_menu()
    return {
        'parent': parent,
        'menuitems_children': menuitems_children,
        # required by the pageurl tag that we want to use within this template
        'request': context['request'],
}


@register.simple_tag()
def webpack_asset(asset):

    try:
        with open(os.path.join(str(settings.PROJECT_ROOT), 'base', 'static', 'bundles', 'manifest.json')) as f:

            manifest = json.load(f)

            if asset in manifest:
                return os.path.join(settings.STATIC_URL,
                                    os.path.basename(os.path.abspath(os.path.join(f.name, os.pardir))),
                                    manifest[asset])
    except OSError as e:
        return '/MISSING.IN.BUNDLE.' + asset


@register.filter
def debugObj(obj):
    import pdb; pdb.set_trace()
    #0/0
    return ''


@register.filter
def assign_request_to_wagtail_model(obj, value):
    if hasattr(obj, 'block'):
        if hasattr(obj.block, 'set_request'):
            func = getattr(obj.block, 'set_request')
            func(value)

    return ''


def x_with_class(obj, x, classname):
    """Add a class to all <x>-elements in the passed HTML"""

    from django.utils.safestring import mark_safe
    from bs4 import BeautifulSoup as bs

    soup = bs(obj, 'html5lib')

    for x_elm in soup.findAll(x):
        x_elm['class'] = x_elm.get('class', []) + [classname]

    # the nested listcomprehension shouldn't be needed, but it is, dont know why
    #return mark_safe(u''.join([ x.decode('utf8') for x in ['%s' % x for x in soup.body.contents]]))

    # but this is waay easier
    return mark_safe(soup.body.encode_contents())


@register.filter
def ul_with_class(obj, classname):
    """Add a class to all <ul>-elements in the passed HTML"""
    ret =  x_with_class(obj, 'ul', classname)
    return ret

@register.filter
def ol_with_class(obj, classname):
    """Add a class to all <ol>-elements in the passed HTML"""
    ret =  x_with_class(obj, 'ol', classname)
    return ret

@register.filter
def p_with_class(obj, classname):
    """Add a class to all <p>-elements in the passed HTML"""
    ret = x_with_class(obj, 'p', classname)
    return ret

@register.filter
def a_with_class(obj, classname):
    """Add a class to all <a>-elements in the passed HTML"""
    ret = x_with_class(obj, 'a', classname)
    return ret

@register.filter
def h4_with_class(obj, classname):
    """Add a class to all <h4>-elements in the passed HTML"""
    ret = x_with_class(obj, 'h4', classname)
    return ret

@register.filter
def h3_with_class(obj, classname):
    """Add a class to all <h3>-elements in the passed HTML"""
    ret = x_with_class(obj, 'h3', classname)
    return ret


@register.filter
def h2_with_class(obj, classname):
    """Add a class to all <h2>-elements in the passed HTML"""
    ret = x_with_class(obj, 'h2', classname)
    return ret


@register.filter
def h1_with_class(obj, classname):
    """Add a class to all <h1>-elements in the passed HTML"""
    ret = x_with_class(obj, 'h1', classname)
    return ret
